import { useEffect, useMemo, useState } from 'react'
import { demoPosts as initialPosts } from './data/demoPosts'

type Post = { id: string; author: string; label: string; body: string; likes: number; liked: boolean; saved: boolean; comments: string[] }

const seed: Post[] = initialPosts.map((p: any) => ({ ...p, likes: 0, liked: false, saved: false, comments: [] }))
const tabs = [
  ['home', 'Início'], ['explore', 'Explorar'], ['saved', 'Salvos'], ['profile', 'Meu perfil'], ['admin', 'Administração']
] as const

function loadPosts(): Post[] {
  try { const raw = localStorage.getItem('newskmusic-demo-posts'); return raw ? JSON.parse(raw) : seed }
  catch { return seed }
}

export default function App() {
  const [page, setPage] = useState<string>('home')
  const [posts, setPosts] = useState<Post[]>(loadPosts)
  const [query, setQuery] = useState('')
  const [draft, setDraft] = useState('')
  const [showComposer, setShowComposer] = useState(false)
  const [notice, setNotice] = useState('')

  useEffect(() => { localStorage.setItem('newskmusic-demo-posts', JSON.stringify(posts)) }, [posts])
  useEffect(() => {
    if (!notice) return
    const timer = window.setTimeout(() => setNotice(''), 2600)
    return () => window.clearTimeout(timer)
  }, [notice])

  const visiblePosts = useMemo(() => {
    let list = page === 'saved' ? posts.filter(p => p.saved) : posts
    if (query.trim()) list = list.filter(p => `${p.author} ${p.body}`.toLowerCase().includes(query.toLowerCase()))
    return list
  }, [posts, page, query])

  function updatePost(id: string, patch: Partial<Post>) {
    setPosts(current => current.map(post => post.id === id ? { ...post, ...patch } : post))
  }
  function createPost() {
    if (!draft.trim()) return
    setPosts(current => [{ id: crypto.randomUUID(), author: 'Você', label: 'Agora · publicação local', body: draft.trim(), likes: 0, liked: false, saved: false, comments: [] }, ...current])
    setDraft(''); setShowComposer(false); setPage('home'); setNotice('Publicação adicionada neste dispositivo.')
  }
  function comment(id: string) {
    const value = window.prompt('Escreva um comentário:')
    if (value?.trim()) {
      setPosts(current => current.map(p => p.id === id ? { ...p, comments: [...p.comments, value.trim()] } : p))
      setNotice('Comentário adicionado neste dispositivo.')
    }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#" onClick={e => {e.preventDefault(); setPage('home')}}>
        <img src="/assets/brand/logo.png" alt="" /><span>NEWSK<span>MUSIC</span></span>
      </a>
      <p className="side-caption">SUA COMUNIDADE K-POP</p>
      <nav>{tabs.map(([id, label]) => <button key={id} className={page === id ? 'nav-item active' : 'nav-item'} onClick={() => {setPage(id); setQuery('')}}>
        <span className="nav-dot">{({home:'⌂',explore:'⌕',saved:'♡',profile:'◉',admin:'✧'} as any)[id]}</span>{label}
      </button>)}</nav>
      <button className="compose-side" onClick={() => setShowComposer(true)}>＋ Criar publicação</button>
      <div className="sidebar-bottom"><span className="online-dot"/> Comunidade em construção <small>Versão 0.2.0 · demonstração</small></div>
    </aside>

    <main className="main">
      <header className="mobile-head">
        <div className="brand"><img src="/assets/brand/logo.png" alt="" /><span>NEWSKMUSIC</span></div>
        <button className="round" onClick={() => setShowComposer(true)} aria-label="Criar publicação">＋</button>
      </header>
      <div className="topline">
        <div><p className="eyebrow">UM ESPAÇO DE FÃ PARA FÃ</p><h1>{page === 'home' ? 'Seu universo K-pop.' : page === 'explore' ? 'Descubra novidades.' : page === 'saved' ? 'Suas publicações salvas.' : page === 'profile' ? 'Seu cantinho.' : 'Painel administrativo.'}</h1></div>
        <label className="search"><span>⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Pesquisar na comunidade" /></label>
      </div>

      {page === 'home' && <section className="hero">
        <div><span className="hero-kicker">NEWSKMUSIC • K-POP COMMUNITY</span><h2>Mais que música,<br/><em>é conexão.</em></h2><p>Um lugar para compartilhar novidades, encontrar outros fãs e celebrar aquilo que a gente ama.</p><button onClick={() => setShowComposer(true)} className="light-button">Compartilhar algo ♡</button></div>
        <img src="/assets/brand/wallpaper.png" alt="Arte roxa e rosa da identidade visual NEWSKMUSIC" />
      </section>}

      {page === 'explore' && <div className="feature-grid">
        <article><span>01 / COMUNIDADE</span><h3>Encontre seu fandom</h3><p>Conecte-se com fãs e descubra conversas sobre seus artistas favoritos.</p></article>
        <article><span>02 / DESCOBERTAS</span><h3>Novas publicações</h3><p>Use a pesquisa para localizar conteúdo no feed de demonstração.</p></article>
        <article><span>03 / COMPARTILHE</span><h3>Faça parte</h3><p>Crie publicações locais e salve conteúdos para consultar depois.</p></article>
      </div>}

      {page === 'profile' && <section className="profile-card"><div className="profile-cover"/><div className="profile-info"><div className="profile-avatar">N</div><div><h2>Seu perfil</h2><p>@novo_fã · Perfil de demonstração</p></div><button className="outline-button" onClick={() => setNotice('A edição de perfil será conectada ao backend na próxima etapa.')}>Editar perfil</button></div><p className="profile-bio">Seu espaço para falar sobre música, artistas e tudo que faz parte do universo K-pop. ♡</p><div className="stats"><span><b>{posts.length}</b> publicações neste dispositivo</span><span><b>0</b> seguidores conectados</span><span><b>Normal</b> plano de demonstração</span></div></section>}

      {page === 'admin' && <section className="admin-note"><span className="admin-lock">✧</span><div><h2>Área administrativa</h2><p>Esta tela é apenas uma prévia visual. Nenhuma autenticação ou permissão administrativa está ativa nesta versão. O painel real deverá validar os papéis no servidor, exigir MFA e registrar ações em auditoria.</p><button className="outline-button" onClick={() => setNotice('A administração real depende da configuração segura do backend.')}>Entendi</button></div></section>}

      {(page === 'home' || page === 'saved' || page === 'explore') && <section className="feed-section">
        <div className="section-title"><div><p className="eyebrow">{page === 'saved' ? 'COLEÇÃO PESSOAL' : 'DA COMUNIDADE'}</p><h2>{page === 'saved' ? 'Salvos' : 'Publicações recentes'}</h2></div><span className="count">{visiblePosts.length} itens</span></div>
        {visiblePosts.length === 0 ? <div className="empty"><span>♡</span><h3>Nada por aqui ainda</h3><p>Quando houver publicações, elas aparecerão nesta área.</p></div> : visiblePosts.map(post => <article className="post-card" key={post.id}>
          <div className="post-head"><div className="avatar">{post.author.slice(0,1).toUpperCase()}</div><div className="author"><b>{post.author}</b><small>{post.label}</small></div><button className="more" aria-label="Mais opções" onClick={() => setNotice('Opções adicionais serão disponibilizadas na versão conectada.')}>•••</button></div>
          <p className="post-body">{post.body}</p>
          <div className="post-actions">
            <button className={post.liked ? 'action selected' : 'action'} onClick={() => updatePost(post.id, { liked: !post.liked, likes: post.likes + (post.liked ? -1 : 1) })}>♡ {post.likes}</button>
            <button className="action" onClick={() => comment(post.id)}>▢ {post.comments.length} comentários</button>
            <button className={post.saved ? 'action selected' : 'action'} onClick={() => {updatePost(post.id, {saved: !post.saved}); setNotice(post.saved ? 'Removido dos salvos.' : 'Adicionado aos salvos.')}}>{post.saved ? '★ Salvo' : '☆ Salvar'}</button>
          </div>
          {post.comments.length > 0 && <div className="comments">{post.comments.map((c,i) => <p key={i}><b>Você:</b> {c}</p>)}</div>}
        </article>)}
      </section>}
      <footer>NEWSKMUSIC · Juntos pelo K-pop ♡ <span>Versão inicial de desenvolvimento</span></footer>
    </main>

    {showComposer && <div className="modal-backdrop" onMouseDown={e => {if(e.target === e.currentTarget) setShowComposer(false)}}><section className="composer" role="dialog" aria-modal="true" aria-labelledby="composer-title"><button className="close" onClick={() => setShowComposer(false)} aria-label="Fechar">×</button><p className="eyebrow">COMPARTILHE COM A COMUNIDADE</p><h2 id="composer-title">Criar publicação</h2><textarea autoFocus value={draft} onChange={e => setDraft(e.target.value)} maxLength={1000} placeholder="O que você gostaria de compartilhar?"/><div className="composer-foot"><small>{draft.length}/1000 · salva apenas neste dispositivo</small><button className="primary-button" disabled={!draft.trim()} onClick={createPost}>Publicar</button></div></section></div>}
    {notice && <div className="toast" role="status">{notice}</div>}
    <nav className="mobile-nav">{tabs.slice(0,4).map(([id,label]) => <button key={id} className={page===id?'active':''} onClick={() => setPage(id)}><span>{({home:'⌂',explore:'⌕',saved:'♡',profile:'◉'} as any)[id]}</span>{label}</button>)}</nav>
  </div>
}
