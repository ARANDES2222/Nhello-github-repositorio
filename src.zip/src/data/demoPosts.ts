// Conteúdo fictício de interface. Não representa notícias ou anúncios reais.
export const demoPosts = [
  { id: 'demo-1', author: 'Equipe NEWSKMUSIC', label: 'Publicação de boas-vindas · demonstração', body: 'Bem-vindos ao nosso espaço! Apresente seu grupo favorito e conheça outros fãs.' },
  { id: 'demo-2', author: 'Comunidade', label: 'Enquete de exemplo · demonstração', body: 'Qual tipo de conteúdo você gostaria de encontrar primeiro por aqui: notícias, comebacks, colecionáveis ou conversas?' },
]
