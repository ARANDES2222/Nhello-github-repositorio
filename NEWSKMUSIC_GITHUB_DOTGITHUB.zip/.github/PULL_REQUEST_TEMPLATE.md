## Resumo
Descreva brevemente o que foi alterado.

## Tipo de alteração
- [ ] Correção de erro
- [ ] Nova funcionalidade
- [ ] Melhoria visual ou de acessibilidade
- [ ] Documentação
- [ ] Manutenção/segurança

## Verificações
- [ ] Revisei o código e removi informações sensíveis.
- [ ] `npm run typecheck` foi executado.
- [ ] `npm run build` foi executado.
- [ ] Testei as alterações relevantes.
- [ ] Atualizei a documentação, se necessário.

## Evidências (opcional)
Inclua capturas de tela ou detalhes dos testes, sem expor dados privados.
