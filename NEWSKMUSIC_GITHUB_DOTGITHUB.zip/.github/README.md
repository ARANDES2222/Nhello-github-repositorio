# Configuração GitHub do NEWSKMUSIC

Esta pasta deve ficar na raiz do repositório, com o nome exato `.github`.

## Conteúdo

- `workflows/ci.yml`: executa instalação de dependências, verificação TypeScript e build em pushes e pull requests para `main` e `master`.
- `dependabot.yml`: verifica semanalmente atualizações das dependências npm e das GitHub Actions.
- `ISSUE_TEMPLATE/`: formulários para relatar erros e sugerir melhorias.
- `PULL_REQUEST_TEMPLATE.md`: checklist para revisões de código.

## Instalação

1. Extraia este ZIP.
2. Coloque a pasta `.github` diretamente na raiz do projeto NEWSKMUSIC, no mesmo nível de `package.json`, `src` e `public`.
3. Se já existir `.github/workflows/ci.yml`, substitua pelo arquivo deste pacote ou compare as configurações antes.
4. Envie a pasta ao GitHub junto com os demais arquivos do projeto.
5. No GitHub, abra a aba **Actions** para acompanhar as verificações.

Os workflows não publicam o aplicativo automaticamente. Eles apenas verificam o código e geram o build. A publicação exige configuração separada de hospedagem e segredos quando aplicável.
