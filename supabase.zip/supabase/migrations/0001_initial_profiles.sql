-- Base mínima ilustrativa. Revise em ambiente de desenvolvimento antes de aplicar em produção.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default 'Novo fã',
  avatar_url text,
  bio text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "profiles are readable"
on public.profiles for select
using (true);

create policy "users insert own profile"
on public.profiles for insert
with check (auth.uid() = id);

create policy "users update own profile"
on public.profiles for update
using (auth.uid() = id)
with check (auth.uid() = id);

-- Não adicionar role editável pelo usuário nesta tabela.
-- Papéis administrativos devem ficar em tabela protegida ou claims geridas no servidor.
