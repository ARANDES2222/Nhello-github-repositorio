# Identidade visual e imagens

Arquivos de marca:
- `public/assets/brand/logo.png`
- `public/assets/brand/wallpaper.png`

A logo recebida é usada como referência visual. Antes de produção, exportar ícones próprios nos tamanhos exigidos por PWA, Android e iOS, mantendo área segura e legibilidade em tamanhos pequenos. O wallpaper não deve ser usado como ícone.

Conteúdo de demonstração em `src/data/demoPosts.ts` é fictício. Substituir somente por publicações autorizadas, com créditos e fontes quando forem notícias.
