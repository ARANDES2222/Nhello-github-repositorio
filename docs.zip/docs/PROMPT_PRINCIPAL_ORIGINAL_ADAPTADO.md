# DESENVOLVIMENTO COMPLETO DA PLATAFORMA NEWSKMUSIC — REDE SOCIAL, COMUNIDADE E MARKETPLACE DE K-POP

Quero que você desenvolva uma plataforma digital completa chamada **NEWSKMUSIC**, que funcione como um site responsivo e também como um aplicativo, com uma experiência moderna, intuitiva, segura, interativa e visualmente encantadora.

Não quero apenas uma página demonstrativa ou um protótipo visual. Quero um produto digital funcional, com frontend, backend, banco de dados, autenticação, gerenciamento de usuários, publicações, mensagens, marketplace, painel administrativo e todas as funcionalidades devidamente conectadas.

O projeto deve ser desenvolvido com arquitetura profissional, código organizado, segurança desde a base e possibilidade de expansão futura.

# 1. CONCEITO E IDENTIDADE DO NEWSKMUSIC

O Newskmusic será uma comunidade digital voltada para fãs de K-pop.

Sua proposta é reunir em um único lugar notícias, atualizações, comebacks, votações, trends, interações entre fãs, amizades e um marketplace especializado na compra e venda de produtos relacionados ao K-pop.

Se fosse necessário resumir o Newskmusic em uma palavra, seria: **ACOLHEDOR**.

Quero que qualquer pessoa que entre na plataforma sinta que está em um espaço criado de fã para fã.

O site não deve parecer um marketplace genérico, uma rede social empresarial ou uma página feita automaticamente por inteligência artificial.

Ele precisa ter personalidade, identidade própria e uma experiência visual cuidadosamente desenvolvida.

# 2. IDENTIDADE VISUAL E DESIGN

A identidade visual deverá seguir uma estética delicada, fofa, moderna e organizada.

**Paleta de cores principal:**
* Rosa pastel.
* Lilás pastel.
* Branco.
* Lavanda clara.
* Tons suaves de rosa e roxo.

Evite cores extremamente fortes, contrastes agressivos, excesso de elementos, efeitos exagerados e interfaces visualmente poluídas.

**Direção visual:**
* Interface delicada e elegante.
* Cantos arredondados.
* Cards com acabamento refinado.
* Sombras suaves.
* Gradientes discretos.
* Ícones delicados.
* Microanimações.
* Transições fluidas.
* Tipografia bonita e legível.
* Espaçamentos equilibrados.
* Elementos visuais inspirados na cultura K-pop, sem copiar identidades protegidas.

O design deve ser responsivo e adaptado a celulares, tablets e computadores.

A versão mobile deve receber atenção especial, pois grande parte dos usuários acessará a plataforma pelo celular.

Não utilize emojis como substitutos de todos os ícones. Utilize uma biblioteca consistente de ícones profissionais.

# 3. PLATAFORMAS E EXPERIÊNCIA DE USO

O Newskmusic deverá possuir:

1. Site público acessível pelo navegador.
2. Aplicativo para Android.
3. Aplicativo para iOS.
4. Painel administrativo exclusivo da proprietária.
5. Aplicação Web Progressiva (PWA) instalável, com experiência própria e documentação de instalação.

A administração inicial deverá conter exatamente duas contas: CEO em `[E-MAIL DA CEO CONFIGURADO PRIVADAMENTE]` e administradora em `[E-MAIL DA SEGUNDA ADMINISTRADORA CONFIGURADO PRIVADAMENTE]`, conforme a seção 27.

Sempre que tecnicamente possível, utilize uma base de código compartilhada entre as plataformas.

A navegação deve ser fluida, sem recarregamentos desnecessários e sem perda de informações.

O aplicativo e o site deverão compartilhar os mesmos dados, contas, publicações, produtos, mensagens e configurações.

# 4. SISTEMA DE CADASTRO E AUTENTICAÇÃO

Crie um sistema completo de contas para os usuários.

O cadastro deverá permitir:

* Nome de usuário.
* Nome de exibição.
* E-mail.
* Número de telefone.
* Senha.
* Confirmação de senha.
* Verificação de e-mail.
* Verificação de telefone por código quando configurada.
* Aceitação dos termos de uso e política de privacidade.

Implemente:

* Login por e-mail e senha.
* Recuperação de senha.
* Alteração de senha.
* Verificação de identidade.
* Encerramento de sessão.
* Gerenciamento de dispositivos e sessões.
* Opção de sair da conta.
* Exclusão de conta.
* Edição de dados pessoais.

Não armazene senhas em texto puro.

Utilize um sistema seguro de autenticação e nunca exponha credenciais ou chaves privadas no frontend.

**Restrição de contas:**

O sistema deverá possuir mecanismos para evitar que pessoas banidas retornem criando novas contas com o mesmo telefone.

Implemente verificação de números telefônicos normalizados, registros de sanções e mecanismos de prevenção de reincidência, respeitando a legislação de proteção de dados.

Não permita que usuários comuns consultem os dados privados de telefone ou e-mail de outras pessoas.

# 5. PÁGINA INICIAL — O CORAÇÃO DO NEWSKMUSIC

A página inicial deverá funcionar como o centro de toda a comunidade.

Quero um feed organizado, dinâmico e constantemente atualizado.

Inclua:

* Notícias de K-pop.
* Atualizações de grupos e artistas.
* Combacks.
* Lançamentos.
* Votações.
* Enquetes.
* Trends.
* Divulgações.
* Publicações de usuários.
* Recomendações.
* Conteúdos populares.
* Atualizações recentes.

Crie filtros para facilitar a navegação.

Permita que os usuários curtam, comentem, compartilhem e salvem publicações.

Inclua uma barra de pesquisa para encontrar conteúdos, artistas, grupos, usuários e produtos.

Não invente notícias reais. Utilize conteúdo fornecido pela administração ou fontes autorizadas e identifique corretamente a origem das notícias.

# 6. MARKETPLACE — COMPRA E VENDA

Crie uma área de vendas completa e integrada à plataforma.

O marketplace será destinado à compra e venda de produtos relacionados ao K-pop.

**Categorias:**
* Álbuns.
* Photocards.
* Lightsticks.
* Merch.
* Pôsteres.
* Colecionáveis.
* Produtos de revenda.
* Outros produtos relacionados ao K-pop.

Cada anúncio deverá possuir:

* Nome do produto.
* Descrição.
* Fotografias.
* Preço.
* Categoria.
* Estado de conservação.
* Disponibilidade.
* Informações do vendedor.
* Data de publicação.
* Botão para conversar com o vendedor.

Crie filtros por preço, categoria, estado do produto e disponibilidade.

Permita que usuários publiquem, editem, pausem e excluam seus próprios anúncios.

**Sistema de vendedores:**

* Perfil de vendedor.
* Avaliações.
* Histórico de anúncios.
* Reputação.
* Denúncias.
* Status dos anúncios.

**Segurança nas negociações:**

Implemente mecanismos de prevenção contra fraudes, anúncios falsos, golpes e vendedores mal-intencionados.

O sistema deve permitir denúncias de produtos e vendedores.

Não simule pagamentos reais. Caso seja implementado pagamento dentro da plataforma, utilize um provedor de pagamentos confiável, com integração segura, confirmação de transações e tratamento de falhas.

# 7. PERFIL DOS USUÁRIOS

Crie uma página de perfil individual e personalizável.

Cada usuário deverá conseguir:

* Adicionar foto de perfil.
* Adicionar capa.
* Criar biografia.
* Editar nome de exibição.
* Editar informações permitidas.
* Consultar publicações próprias.
* Consultar favoritos.
* Visualizar anúncios publicados.
* Acompanhar seguidores.
* Visualizar quem segue.
* Consultar avaliações como vendedor.
* Gerenciar configurações de privacidade.

Inclua um editor de perfil moderno e intuitivo.

O usuário deverá conseguir visualizar suas alterações antes de salvá-las.

Permita controlar quais informações ficam públicas e quais ficam privadas.

# 8. SISTEMA SOCIAL E PUBLICAÇÕES

Crie um sistema completo de interação entre os usuários.

Funcionalidades:

* Publicações com texto.
* Publicações com imagens.
* Publicações com vídeos.
* Curtidas.
* Comentários.
* Respostas.
* Compartilhamentos.
* Favoritos.
* Seguidores.
* Seguindo.
* Enquetes.
* Menções.
* Notificações de interação.

Cada publicação deverá possuir opções de edição e exclusão para seu autor, além de ferramentas de denúncia.

Implemente um feed que apresente conteúdos relevantes sem prejudicar a privacidade dos usuários.

# 9. SISTEMA DE MENSAGENS E COMUNICAÇÃO

Desenvolva um sistema de mensagens integrado.

Inclua:

* Conversas privadas.
* Mensagens em tempo real.
* Envio de imagens.
* Envio de arquivos permitidos.
* Respostas a mensagens.
* Indicador de mensagens não lidas.
* Histórico de conversas.
* Bloqueio de usuários.
* Denúncia de mensagens.
* Opções de privacidade.

O usuário deverá conseguir conversar diretamente com vendedores sem sair da plataforma.

Implemente controles para impedir spam, assédio e envio abusivo de mensagens.

Não exponha conversas privadas ao público ou a usuários não autorizados.

# 10. SISTEMA DE DENÚNCIAS, PUNIÇÕES E BANIMENTOS

Este é um dos sistemas mais importantes do Newskmusic.

Crie uma estrutura completa de moderação.

Os usuários poderão denunciar:

* Perfis.
* Publicações.
* Comentários.
* Mensagens.
* Produtos.
* Vendedores.
* Comportamentos inadequados.

**Sistema de três denúncias:**

Quero que o sistema considere três denúncias válidas e independentes contra um mesmo usuário como um limite para aplicação automática de banimento.

Entretanto, não considere qualquer denúncia como automaticamente verdadeira.

Implemente:
* Identificação de denúncias duplicadas.
* Proteção contra denúncias falsas em massa.
* Registro de motivos.
* Verificação automática de padrões abusivos.
* Possibilidade de revisão administrativa.
* Histórico de punições.
* Registro de evidências.
* Sistema de recurso contra banimento.

Quando três denúncias válidas e independentes forem confirmadas conforme as regras da plataforma, o sistema deverá aplicar a sanção configurada.

Para casos graves, permita intervenção administrativa imediata.

**Prevenção de retorno:**

Quando uma conta for banida, registre de maneira protegida os identificadores necessários para impedir a criação de novas contas pelo mesmo telefone verificado.

Não permita que o usuário contorne uma sanção simplesmente criando outro perfil.

Implemente mecanismos adicionais de prevenção de reincidência, sem realizar coleta indiscriminada de dados pessoais.

# 11. PAINEL ADMINISTRATIVO EXCLUSIVO DA PROPRIETÁRIA

Crie uma área administrativa independente da plataforma pública.

Ela deverá ser acessível somente pelas duas contas administrativas iniciais autorizadas e por eventuais contas adicionais que a CEO venha a aprovar posteriormente.

A conta `[E-MAIL DA CEO CONFIGURADO PRIVADAMENTE]` será a CEO e possuirá controle administrativo principal. A conta `[E-MAIL DA SEGUNDA ADMINISTRADORA CONFIGURADO PRIVADAMENTE]` será a segunda administradora, com permissões controladas. A configuração inicial deverá conter exatamente duas contas administrativas, conforme a seção 27.

**Funcionalidades administrativas:**

* Dashboard com estatísticas.
* Total de usuários.
* Usuários ativos.
* Novos cadastros.
* Comunidades e publicações.
* Anúncios ativos.
* Denúncias pendentes.
* Usuários suspensos.
* Usuários banidos.
* Gerenciamento de notícias.
* Gerenciamento de categorias.
* Gerenciamento de conteúdos.
* Gerenciamento de anúncios.
* Gerenciamento de contas.
* Controle de permissões.
* Histórico de atividades administrativas.

Crie também uma área para:

* Revisar denúncias.
* Consultar evidências.
* Aprovar ou rejeitar denúncias.
* Aplicar advertências.
* Suspender contas.
* Banir usuários.
* Reverter punições quando necessário.
* Analisar recursos.

**Segurança administrativa:**

A área administrativa nunca poderá ser acessada apenas por conhecer uma URL.

Implemente autenticação, autorização por função, verificação de permissões no servidor e proteção contra escalonamento de privilégios.

Somente a proprietária autorizada deverá possuir as permissões administrativas principais.

Não crie credenciais administrativas públicas ou senhas fixas dentro do código.

# 12. NOTIFICAÇÕES

Crie um sistema de notificações em tempo real.

Notificações para:

* Novos seguidores.
* Curtidas.
* Comentários.
* Respostas.
* Mensagens.
* Atualizações de anúncios.
* Interações de vendedores.
* Alertas administrativos.
* Atualizações relevantes da comunidade.

Permita configurar quais notificações o usuário deseja receber.

Implemente notificações no aplicativo e no navegador, conforme a compatibilidade da plataforma.

# 13. CONFIGURAÇÕES E PRIVACIDADE

Crie uma central de configurações com:

* Dados da conta.
* Alteração de senha.
* Privacidade.
* Segurança.
* Notificações.
* Gerenciamento de sessões.
* Usuários bloqueados.
* Preferências.
* Exclusão de conta.
* Termos de uso.
* Política de privacidade.
* Central de ajuda.

O usuário deverá possuir controle real sobre seus dados.

# 14. ARQUITETURA E BANCO DE DADOS

Desenvolva um backend organizado, seguro e escalável.

Utilize preferencialmente:

* React Native.
* Expo.
* TypeScript.
* Supabase.
* PostgreSQL.
* Supabase Authentication.
* Supabase Storage.
* Supabase Realtime.

Organize as entidades do banco de dados para usuários, perfis, publicações, comentários, curtidas, seguidores, produtos, vendedores, mensagens, conversas, denúncias, punições, notificações e registros administrativos.

Implemente políticas RLS para proteger todas as informações.

Crie índices, relacionamentos, validações e regras de integridade.

Não permita que o frontend seja a única camada responsável pela segurança.

Todas as operações sensíveis deverão ser verificadas no servidor.

# 15. AUDITORIA TÉCNICA COMPLETA — OBRIGATÓRIA

Não quero que o projeto seja entregue apenas com as telas funcionando visualmente.

Quero uma auditoria técnica e funcional de toda a plataforma.

**Verifique e corrija:**

* Erros 404.
* Erros 500.
* Erros 401 e 403.
* Erros de autenticação.
* Erros de autorização.
* Links quebrados.
* Rotas inexistentes.
* Botões sem funcionamento.
* Formulários com falhas.
* Problemas de navegação.
* Erros de JavaScript e TypeScript.
* Erros de CSS.
* Problemas de responsividade.
* Falhas de carregamento de imagens.
* Falhas de carregamento de vídeos.
* Falhas de comunicação com APIs.
* Erros de banco de dados.
* Falhas no envio de mensagens.
* Problemas de upload.
* Problemas de notificações.
* Perda de dados após atualizar a página.
* Falhas de sessão.
* Problemas de permissões.
* Travamentos.
* Carregamentos infinitos.
* Páginas em branco.
* Falhas de desempenho.

Crie páginas personalizadas para erros 404, 403, 500 e demais situações relevantes.

A página 404 deverá possuir uma aparência coerente com o Newskmusic e um botão funcional para retornar à página inicial.

Implemente estados de carregamento, mensagens de erro compreensíveis, tentativas controladas de recuperação e estados vazios bem desenhados.

Não permita que uma falha isolada derrube toda a plataforma.

# 16. TESTES OBRIGATÓRIOS DE TODAS AS PÁGINAS

Antes de considerar o projeto concluído, percorra e teste todas as páginas e funcionalidades.

Crie uma lista de testes cobrindo:

**Autenticação:**
* Cadastro.
* Login.
* Logout.
* Recuperação de senha.
* Verificação de e-mail.
* Verificação de telefone.
* Edição de conta.
* Exclusão de conta.

**Navegação:**
* Todas as rotas.
* Todos os menus.
* Todos os botões.
* Links internos e externos.
* Navegação no celular.
* Navegação no computador.

**Funcionalidades sociais:**
* Publicações.
* Curtidas.
* Comentários.
* Seguidores.
* Favoritos.
* Mensagens.
* Notificações.

**Marketplace:**
* Criação de anúncios.
* Edição de anúncios.
* Exclusão de anúncios.
* Pesquisa.
* Filtros.
* Contato com vendedores.
* Denúncias.

**Administração:**
* Login administrativo.
* Controle de acesso.
* Gerenciamento de usuários.
* Moderação.
* Banimentos.
* Revisão de denúncias.

**Compatibilidade:**
* Android.
* iOS.
* Chrome.
* Firefox.
* Safari.
* Diferentes tamanhos de tela.

Utilize testes automatizados quando possível, incluindo testes unitários, integração e testes ponta a ponta.

Teste também permissões com contas de diferentes níveis.

Não considere uma funcionalidade aprovada apenas porque sua tela aparece corretamente.

# 17. DESEMPENHO E ESCALABILIDADE

Otimize a plataforma para funcionar de maneira rápida e estável.

Implemente:

* Carregamento otimizado de imagens.
* Paginação de publicações.
* Carregamento sob demanda.
* Cache quando apropriado.
* Consultas eficientes ao banco.
* Índices adequados.
* Controle de requisições.
* Limites de upload.
* Compressão de imagens.
* Monitoramento de erros.
* Monitoramento de desempenho.
* Backups.
* Proteção contra abuso de recursos.

A arquitetura deverá estar preparada para crescimento gradual do número de usuários, sem prometer capacidade ilimitada ou estabilidade absoluta.

# 18. ORGANIZAÇÃO E QUALIDADE DO CÓDIGO

Mantenha uma arquitetura limpa e profissional.

Crie componentes reutilizáveis e separe adequadamente:

* Frontend.
* Backend.
* Serviços.
* Autenticação.
* Banco de dados.
* Componentes.
* Telas.
* Rotas.
* Configurações.
* Testes.
* Documentação.

Não misture credenciais com código público.

Não deixe funções incompletas escondidas em telas aparentemente finalizadas.

Não substitua funcionalidades reais por dados fictícios sem identificar claramente que são dados de demonstração.

Mantenha documentação das configurações, variáveis de ambiente, dependências e processos de execução.

# 19. CRITÉRIOS DE ENTREGA

O Newskmusic somente deverá ser considerado pronto quando:

1. O site estiver funcional.
2. A experiência mobile estiver funcional.
3. O aplicativo Android estiver preparado para instalação.
4. O aplicativo iOS estiver preparado para compilação e distribuição.
5. O cadastro e login funcionarem.
6. Os usuários conseguirem editar suas contas.
7. O marketplace estiver conectado ao backend.
8. As publicações funcionarem.
9. As mensagens funcionarem.
10. O painel administrativo estiver protegido.
11. As regras de moderação estiverem implementadas.
12. As permissões estiverem verificadas.
13. Todas as páginas tiverem sido testadas.
14. Os erros encontrados tiverem sido corrigidos ou documentados.
15. A plataforma possuir documentação de instalação e manutenção.

# 20. MODO DE TRABALHO DA IA

Trabalhe como uma equipe profissional de desenvolvimento de software, assumindo responsabilidades de arquitetura, programação frontend, backend, segurança, design e testes.

Desenvolva o projeto por etapas.

Antes de iniciar cada etapa:
* Analise o que já existe.
* Verifique a arquitetura.
* Identifique dependências.
* Planeje as alterações.

Depois de cada etapa:
* Execute os testes.
* Verifique os erros.
* Corrija os problemas.
* Informe o que foi concluído.
* Informe o que ainda falta.
* Preserve todas as funcionalidades anteriormente aprovadas.

Não avance deixando erros críticos conhecidos sem solução.

Não afirme que realizou testes que não foram executados.

Não declare que a plataforma está pronta se existirem funções apenas visuais, integrações pendentes ou falhas importantes.

**PRIMEIRA AÇÃO:**

Comece analisando os requisitos e propondo a arquitetura completa do Newskmusic.

Em seguida, configure a estrutura inicial do projeto, prepare o banco de dados e desenvolva a identidade visual e as primeiras telas.

Não tente implementar tudo em uma única operação. Construa uma plataforma real, funcional, segura, organizada e preparada para evoluir.

**OBJETIVO FINAL:**

O Newskmusic deve ser muito mais do que um site de K-pop.

Deve ser um espaço acolhedor onde fãs possam se informar, fazer amizades, compartilhar experiências, comprar, vender, conversar e se sentir em casa.

Um lugar criado de fã para fã.

# 21. SISTEMA DE SALVAMENTO, REPUBLICAÇÃO E COMPARTILHAMENTO

Quero que o Newskmusic possua um sistema completo de salvamento e republicação de conteúdos.

**Salvar publicações:**
* Adicionar botão de salvar em todas as publicações.
* Permitir salvar notícias, imagens, vídeos e outros conteúdos.
* Criar uma área chamada "Salvos" dentro do perfil do usuário.
* Organizar os conteúdos salvos.
* Permitir remover conteúdos dos salvos.
* Garantir que cada usuário tenha sua própria coleção privada.
* Salvar os conteúdos de forma persistente no banco de dados.

**Republicar conteúdos:**
* Criar botão de republicação nas publicações.
* Permitir republicar conteúdos de outros usuários.
* Exibir o conteúdo original e identificar claramente seu autor.
* Registrar quem republicou.
* Mostrar republicações no perfil e no feed.
* Permitir adicionar um comentário ou texto próprio à republicação.
* Permitir cancelar ou excluir uma republicação.
* Manter os créditos do criador original.
* Respeitar as configurações de privacidade e as permissões do conteúdo original.

**Compartilhamento:**
* Permitir compartilhar publicações dentro do Newskmusic.
* Permitir copiar o link de uma publicação.
* Permitir compartilhar links externamente.
* Criar prévias bonitas dos conteúdos compartilhados.

# 22. ABA DE PESQUISA E DESCOBERTA

Crie uma aba exclusiva de pesquisa, com ícone de lupa na navegação principal.

Ela deverá permitir pesquisar praticamente tudo dentro do Newskmusic.

**Categorias de pesquisa:**
* Usuários.
* Grupos de K-pop.
* Artistas.
* Notícias.
* Publicações.
* Comunidades e assuntos.
* Produtos.
* Vendedores.

**Funcionalidades:**
* Campo de pesquisa com aparência moderna.
* Sugestões enquanto o usuário digita.
* Histórico de pesquisas.
* Opção para limpar o histórico.
* Pesquisas recentes.
* Conteúdos populares.
* Pesquisas em alta.
* Filtros por categoria.
* Ordenação por relevância e data.
* Resultados atualizados conforme a pesquisa.

A pesquisa deverá funcionar de verdade, utilizando dados do banco de dados e não resultados fictícios.

Crie uma tela de resultados organizada, com categorias separadas e cards visualmente agradáveis.

Não exiba informações privadas de usuários nos resultados.

# 23. MICROANIMAÇÕES E TRANSIÇÕES INTERATIVAS

Quero que absolutamente toda a experiência do Newskmusic seja agradável e interativa.

Todos os elementos clicáveis deverão possuir pequenas respostas visuais ao serem acionados.

Implemente microanimações delicadas, rápidas e elegantes em:

* Botões.
* Ícones.
* Curtidas.
* Salvamentos.
* Republicações.
* Comentários.
* Abas.
* Menus.
* Cards.
* Fotos de perfil.
* Publicações.
* Navegação entre páginas.
* Abertura de janelas.
* Pop-ups.
* Notificações.
* Campos de pesquisa.
* Seleção de categorias.
* Botões de compra.
* Ações de edição.

**Exemplos de interações desejadas:**

1. Ao curtir uma publicação, o coração deverá apresentar uma pequena animação.
2. Ao salvar um conteúdo, o ícone deverá mudar suavemente de estado.
3. Ao tocar em um botão, deverá existir uma pequena resposta visual de pressão.
4. Ao abrir uma página, deverá ocorrer uma transição suave.
5. Ao abrir um menu, ele deverá aparecer com uma animação discreta.
6. Ao trocar de aba, a navegação deverá apresentar uma transição fluida.
7. Ao receber uma notificação, deverá existir um indicador visual delicado.
8. Ao republicar, deverá aparecer uma confirmação visual elegante.

As animações devem ser leves, sem prejudicar o desempenho ou causar travamentos.

Não utilize animações exageradas, demoradas ou repetitivas.

Respeite a configuração de acessibilidade para redução de movimento do dispositivo.

# 24. VERSÃO INSTALÁVEL — APLICATIVO PARA DOWNLOAD

Esta exigência é obrigatória: não quero somente um site responsivo.

Quero que o Newskmusic também tenha uma versão de aplicativo que os usuários possam baixar e instalar em seus dispositivos.

**ANDROID:**
* Desenvolver aplicativo instalável.
* Preparar compilação em formato APK para testes e distribuição compatível.
* Preparar versão Android App Bundle (AAB) para publicação na Google Play.
* Criar ícone próprio do aplicativo.
* Configurar nome e identidade visual.
* Criar tela de abertura (Splash Screen).
* Configurar notificações push.
* Implementar navegação adaptada para celulares.
* Testar instalação, atualização e funcionamento.

**IOS:**
* Preparar aplicativo para compilação e distribuição pela App Store.
* Configurar ícone e tela de abertura.
* Implementar notificações push quando configuradas.
* Testar funcionamento em dispositivos compatíveis.

**VERSÃO WEB:**
* Site responsivo.
* Compatibilidade com computadores, tablets e celulares.
* Possibilidade de instalação como PWA em navegadores compatíveis.
* A PWA deverá ser um produto web instalável real, não apenas uma página responsiva com um botão fictício de instalação.
* Ícone próprio.
* Manifesto de aplicativo web.
* Tela de abertura quando suportada.
* Experiência de navegação semelhante a um aplicativo.

**IMPORTANTE:**

As versões Web, Android e iOS deverão compartilhar a mesma conta e os mesmos dados.

Um usuário que criar uma conta no site deverá conseguir entrar com ela no aplicativo.

Uma publicação feita pelo celular deverá aparecer também na versão web.

Uma mensagem recebida no aplicativo deverá estar disponível na versão web, respeitando as regras de sincronização e privacidade.

Não entregue apenas uma página que simula um aplicativo. Gere os projetos e arquivos de compilação necessários para produzir os aplicativos reais.

Configure o processo de build e documente como gerar os arquivos de instalação e publicação.

Não declare que os aplicativos estão publicados nas lojas sem que a publicação tenha sido realmente concluída.

# 25. ATUALIZAÇÃO DA NAVEGAÇÃO PRINCIPAL

Organize a navegação principal para que todas as funcionalidades sejam facilmente encontradas.

Sugestão de navegação:

* Início: feed principal e atualizações.
* Explorar: pesquisa de usuários, artistas, grupos, notícias e produtos.
* Marketplace: compra e venda.
* Criar: publicações e republicações.
* Chats: conversas e mensagens.
* Perfil: informações pessoais, publicações, republicações e salvos.

No aplicativo mobile, utilize uma barra de navegação inferior elegante.

Na versão desktop, adapte a navegação para uma estrutura mais ampla e organizada.

Garanta que nenhuma dessas áreas seja apenas decorativa: todas deverão estar conectadas às funcionalidades reais do sistema.

# 26. TESTES ADICIONAIS OBRIGATÓRIOS

Inclua na auditoria geral os seguintes testes:

* Salvar e remover publicações dos favoritos.
* Verificar persistência dos conteúdos salvos.
* Republicar publicações.
* Cancelar republicações.
* Preservar créditos dos autores originais.
* Pesquisar usuários e produtos.
* Testar filtros de pesquisa.
* Testar histórico de pesquisas.
* Verificar todas as microanimações.
* Testar transições entre páginas.
* Verificar funcionamento em celulares.
* Instalar e testar a versão APK.
* Testar a versão web instalável.
* Verificar sincronização entre aplicativo e site.
* Testar notificações.
* Verificar desempenho das animações.
* Testar acessibilidade e redução de movimento.

Não considere essas funcionalidades concluídas apenas porque seus botões aparecem na interface. Todas devem funcionar corretamente, salvar os dados necessários e passar pelos testes correspondentes.

# 27. ADMINISTRAÇÃO AVANÇADA — EXATAMENTE DUAS CONTAS ADMINISTRATIVAS INICIAIS

Configure inicialmente exatamente duas contas administrativas, usando os endereços informados pela proprietária. Não crie uma terceira conta administrativa inicial.

## 27.1. Contas administrativas iniciais

1. **CEO / Administradora principal / Proprietária**
   - E-mail de login: `[E-MAIL DA CEO CONFIGURADO PRIVADAMENTE]`
   - Função: CEO e administradora principal da plataforma.
   - Permissões: controle geral, gerenciamento da segunda administradora, gestão de funções e permissões, configurações críticas, políticas da plataforma, gestão de pagamentos e assinaturas, auditoria, relatórios e decisões administrativas finais.

2. **Administradora**
   - E-mail de login: `[E-MAIL DA SEGUNDA ADMINISTRADORA CONFIGURADO PRIVADAMENTE]`
   - Função: administradora com permissões operacionais concedidas pela CEO.
   - Permissões iniciais recomendadas: moderação de denúncias e conteúdos, suporte aos usuários, gerenciamento de notícias e categorias e acompanhamento de publicações e anúncios. Acesso a dados financeiros, gestão de credenciais, exclusão da conta da CEO e configurações críticas deverá permanecer bloqueado, salvo autorização explícita e auditável da CEO.

Os dois endereços foram fornecidos pela proprietária e devem ser tratados como identificadores pretendidos para as contas administrativas do NEWSKMUSIC. Antes de ativar cada conta, confirme o controle do respectivo e-mail por link ou código de verificação. Não tente criar caixas postais Gmail, alterar contas externas ou presumir que os endereços foram verificados. A plataforma apenas criará os registros de usuário/administrador no próprio sistema após a confirmação.

## 27.2. Senha inicial e ativação segura

A proprietária informou `[SENHA REMOVIDA — CONFIGURAR PRIVADAMENTE]` como senha inicial pretendida para a configuração. Como essa senha é simples e já foi compartilhada durante o planejamento, trate-a exclusivamente como senha temporária de bootstrap, nunca como senha permanente ou segura para produção.

Requisitos obrigatórios:
* Se a arquitetura e o provedor de autenticação permitirem, usar a senha informada somente para o primeiro acesso em ambiente controlado, com troca obrigatória imediata antes de liberar qualquer função administrativa.
* Preferir convites individuais de ativação ou links de definição de senha enviados aos e-mails verificados. Se for usado convite, cada administradora deverá criar sua própria senha forte e exclusiva.
* Nunca inserir a senha em código-fonte, frontend, arquivos `.env` versionados, documentação pública, logs, mensagens de erro, banco de dados em texto puro ou no ZIP final distribuído.
* Nunca compartilhar a mesma senha como credencial permanente das duas contas.
* Usar o serviço de autenticação para armazenar credenciais com hashing seguro; a aplicação não deverá implementar armazenamento manual de senhas.
* Exigir MFA para ambas as contas administrativas sempre que o provedor suportar.
* Aplicar limitação de tentativas, proteção contra força bruta, alertas de novo dispositivo, expiração e revogação de sessões e recuperação segura de acesso.
* Não registrar senhas, códigos MFA, tokens de sessão ou links secretos na trilha de auditoria.

Se a senha temporária não puder ser usada com segurança, ignore-a e use exclusivamente convites individuais para definição de senha. Não bloqueie a entrega por tentar automatizar a criação de caixas postais externas: documente a etapa que depende da confirmação dos titulares.

## 27.3. Papéis, permissões e auditoria

Implemente RBAC (controle de acesso baseado em funções) e princípio do menor privilégio. A CEO será a única administradora principal inicial. A segunda administradora terá permissões concedidas e revogáveis. A autorização deve ser verificada no backend e no banco de dados, não apenas ocultando botões no frontend.

A segunda administradora não poderá promover a si mesma, alterar o papel da CEO, remover a CEO, mudar credenciais da CEO ou conceder privilégios superiores aos próprios. A CEO poderá ajustar as permissões da segunda administradora e revogar seu acesso. Proteja a plataforma contra escalonamento de privilégios e mantenha trilha de auditoria imutável ou protegida contra alterações comuns, com data, ator, ação, alvo e resultado.

Crie testes que confirmem que existem apenas essas duas contas administrativas iniciais, que cada e-mail precisa ser verificado e que cada função só acessa os recursos autorizados.

# 28. PERFIL PERSONALIZÁVEL COM FOTO, GIF E CAPA

Transforme o perfil em uma das áreas mais expressivas do Newskmusic. O usuário deverá conseguir personalizar sua identidade visual sem comprometer desempenho, acessibilidade ou segurança.

## 28.1. Foto de perfil com GIF

Permita que o usuário escolha:
* Foto estática nos formatos permitidos.
* GIF animado como foto de perfil.
* Pré-visualização antes de salvar.
* Ajuste de enquadramento, posição e zoom.
* Substituição ou remoção da imagem.
* Restauração de uma imagem padrão.

O GIF deverá funcionar nas áreas em que a foto de perfil aparece, como perfil, comentários, publicações, chats e listas de seguidores, respeitando as configurações de privacidade.

Implemente validação real do tipo do arquivo, tamanho máximo, dimensões e duração. Defina limites configuráveis no painel administrativo, otimize o processamento e gere uma alternativa estática quando necessário. Não confie apenas na extensão do arquivo: valide o conteúdo recebido no servidor, bloqueie arquivos maliciosos e armazene imagens em serviço seguro.

Ofereça uma opção para reduzir animações ou exibir uma imagem estática, respeitando as preferências de acessibilidade e economia de dados. Não permita que GIFs causem carregamento infinito, travamentos ou consumo excessivo de memória.

## 28.2. Personalização visual do perfil

Disponibilize, conforme o nível da conta:
* Foto de perfil.
* Imagem de capa.
* Biografia.
* Cor ou tema de perfil.
* Molduras de avatar.
* Selos e distintivos.
* Cartões de destaque.
* Seções organizáveis.
* Pré-visualização do perfil público.
* Controles para ocultar informações e seções.

O usuário deverá visualizar o resultado antes de publicar as alterações. A personalização nunca poderá ocultar ferramentas de denúncia, bloqueio, segurança ou informações obrigatórias.

# 29. DOIS NÍVEIS DE EXPERIÊNCIA — NORMAL E NEWSKMUSIC VIP

Implemente dois níveis de conta: **Normal (gratuito)** e **NEWSKMUSIC VIP (assinatura paga)**. A conta gratuita deverá continuar sendo útil e completa para participar da comunidade. O VIP oferecerá personalização e benefícios adicionais, sem tornar a plataforma injusta ou prejudicar a segurança.

## 29.1. Conta Normal — gratuita

A conta Normal deverá permitir, conforme os limites gerais e regras de uso:
* Criar perfil e adicionar foto estática.
* Publicar textos, imagens e interagir com a comunidade.
* Curtir, comentar, seguir e compartilhar.
* Participar de enquetes e comunidades.
* Pesquisar usuários, artistas, grupos, notícias e produtos.
* Utilizar mensagens conforme as regras de segurança.
* Comprar e vender no marketplace, quando elegível.
* Salvar publicações.
* Utilizar as opções básicas de privacidade.
* Acessar as configurações e solicitar suporte.

Os limites de uso, armazenamento e publicação deverão ser transparentes, razoáveis e configuráveis. Não retire funcionalidades essenciais de segurança ou controle da conta de usuários gratuitos.

## 29.2. NEWSKMUSIC VIP — R$ 19,99 por mês

Crie uma assinatura VIP com preço inicial de **R$ 19,99 por mês**, exibido de forma clara antes da confirmação da compra.

Benefícios VIP propostos:
* Utilizar GIF animado como foto de perfil, dentro dos limites técnicos definidos.
* Acesso a molduras VIP exclusivas para avatar.
* Temas e opções extras de personalização do perfil.
* Capa de perfil com opções visuais adicionais.
* Selos visuais de membro VIP.
* Cartões de destaque personalizáveis no perfil.
* Mais opções de organização e apresentação das seções do perfil.
* Coleções e áreas de favoritos com recursos extras.
* Opções adicionais de decoração e identidade visual.
* Destaque visual de perfil, quando habilitado pelo usuário e sujeito às regras de transparência.
* Acesso antecipado a recursos experimentais, quando disponíveis, sem garantia de funcionalidades ainda não lançadas.

A lista final de benefícios deverá ser exibida em uma página comparativa entre Normal e VIP, para que a pessoa saiba exatamente o que está comprando. Não prometa benefícios que ainda não estejam implementados.

## 29.3. Pagamento, ativação e gestão da assinatura

Implemente a assinatura com um provedor de pagamentos confiável e compatível com o mercado brasileiro.

Requisitos:
* Exibir preço, periodicidade, condições e benefícios antes da compra.
* Informar se a renovação é automática ou manual.
* Permitir consultar o status da assinatura.
* Permitir cancelar a renovação e consultar a data de término do acesso.
* Registrar pagamentos, recusas, estornos e reembolsos.
* Ativar VIP somente após confirmação confiável do pagamento pelo backend ou webhook validado.
* Validar assinatura e permissões no servidor, nunca apenas no aplicativo.
* Tratar pagamentos pendentes, expirados, duplicados e falhos.
* Não armazenar dados completos de cartão.
* Não simular pagamentos reais nem marcar usuário como VIP apenas porque clicou em um botão.
* Disponibilizar histórico de cobrança e canal de suporte.
* Explicar o que acontece com os benefícios quando a assinatura termina.

O valor de R$ 19,99 deverá ser configurável pela proprietária no painel administrativo, com registro de alterações e sem mudar silenciosamente o preço de assinantes existentes. Qualquer mudança deverá ser comunicada de forma transparente e obedecer às regras aplicáveis.

# 30. SISTEMA DE DESTAQUES E VISIBILIDADE DE PERFIS

Crie uma área de destaques que valorize a comunidade e permita que os usuários apresentem melhor seus perfis e conteúdos.

Recursos:
* Cartão de perfil em destaque.
* Seção de perfis VIP em evidência.
* Destaques escolhidos pelo próprio usuário.
* Publicações fixadas no próprio perfil.
* Cartões de conquistas e selos.
* Destaques de coleções, grupos favoritos e interesses.
* Controles para ativar, editar, ordenar e remover destaques.
* Pré-visualização em dispositivos móveis e desktop.

Regras de transparência e justiça:
* Identifique claramente qualquer destaque patrocinado ou impulsionado por pagamento.
* Não misture publicidade com recomendação orgânica sem identificação.
* Não prometa que o VIP garante popularidade, seguidores, curtidas ou vendas.
* Não permita que o pagamento altere denúncias, punições, avaliações de vendedores ou decisões de moderação.
* Não dê prioridade administrativa ou imunidade a membros VIP.
* Respeite bloqueios, privacidade, preferências de conteúdo e critérios de segurança.
* Ofereça critérios compreensíveis para destaques orgânicos, como relevância, qualidade e participação, sem revelar dados privados.

# 31. EXPERIÊNCIA DE COMPRA DO VIP E COMPARAÇÃO DE PLANOS

Crie uma página de apresentação do NEWSKMUSIC VIP com identidade visual delicada, coerente com rosa pastel, lilás, branco e lavanda.

A página deverá conter:
* Explicação objetiva do que é o VIP.
* Comparação entre conta Normal e VIP.
* Lista dos benefícios realmente disponíveis.
* Preço de R$ 19,99 por mês.
* Informação sobre cobrança e renovação.
* Botão para assinar.
* Etapa de confirmação antes de pagar.
* Link para termos da assinatura e política de cancelamento.
* Perguntas frequentes.
* Estado de processamento, sucesso, pendência ou falha do pagamento.

Não use contadores falsos, escassez artificial, depoimentos inventados ou mensagens enganosas. O usuário deverá poder continuar utilizando a conta Normal caso não queira assinar.

# 32. PAINEL ADMINISTRATIVO — CONTROLE DE VIP, PERFIS E DESTAQUES

Acrescente ao painel da proprietária:
* Visualizar quantidade de assinantes VIP ativos.
* Consultar assinaturas pendentes, canceladas e expiradas.
* Consultar histórico de pagamentos conforme as permissões.
* Configurar preço e benefícios, com histórico de alterações.
* Gerenciar molduras, temas, selos e opções de perfil.
* Configurar limites de upload para fotos e GIFs.
* Moderar imagens de perfil, capas e destaques denunciados.
* Gerenciar critérios de destaques orgânicos.
* Identificar conteúdos patrocinados.
* Suspender benefícios em casos previstos nos termos, com justificativa e possibilidade de recurso.
* Consultar registros de alterações administrativas.

As administradoras de moderação e operações terão apenas as permissões necessárias. Informações financeiras e dados pessoais sensíveis ficarão restritos à proprietária e às funções autorizadas.

# 33. PRIVACIDADE, CONSUMIDOR E PROTEÇÃO DE DADOS

Implemente os novos recursos em conformidade com a LGPD e demais regras aplicáveis ao serviço e ao meio de pagamento.

* Solicite apenas os dados necessários.
* Informe a finalidade da coleta e o período de retenção.
* Permita ao usuário consultar, corrigir e solicitar a exclusão de seus dados conforme a legislação.
* Proteja e-mails, telefones, histórico de compras e mensagens.
* Não use dados privados para criar destaques públicos.
* Não compartilhe dados de pagamento com outros usuários.
* Apresente termos claros para assinatura, renovação e cancelamento.
* Mantenha controles de acesso, logs protegidos e procedimentos de resposta a incidentes.

# 34. TESTES OBRIGATÓRIOS DOS NOVOS RECURSOS

Antes da entrega, teste:

**Administradores**
* Criação e ativação das exatamente duas contas administrativas iniciais.
* Validação dos e-mails confirmados.
* Separação das permissões.
* Bloqueio de acesso não autorizado.
* Troca obrigatória da senha temporária.
* MFA, recuperação e revogação de sessões.
* Registro de ações e histórico de auditoria.

**Perfis e GIFs**
* Upload de foto estática e GIF.
* Pré-visualização, recorte, substituição e remoção.
* Validação de formato, tamanho e conteúdo.
* Exibição em perfil, feed, comentários e chats.
* Alternativa estática e redução de movimento.
* Testes de desempenho e segurança do upload.

**VIP e pagamentos**
* Visualização correta do preço de R$ 19,99 por mês.
* Comparação entre planos.
* Pagamento aprovado, recusado, pendente e expirado.
* Validação de webhook.
* Ativação e encerramento de benefícios.
* Cancelamento e histórico de cobrança.
* Tentativas de fraude e manipulação do status VIP pelo frontend.

**Destaques**
* Criar, editar, ordenar e remover destaques.
* Verificar identificação de conteúdo patrocinado.
* Respeitar bloqueios e privacidade.
* Confirmar que VIP não interfere na moderação ou reputação.

# 35. REGRAS DE IMPLEMENTAÇÃO E ENTREGA DESTA ATUALIZAÇÃO

Não trate este adendo como uma simples descrição visual. Integre os recursos à arquitetura, banco de dados, autenticação, armazenamento, backend, painel administrativo e testes do projeto.

Antes de programar:
1. Analise a estrutura atual do projeto.
2. Identifique o que já existe e o que está ausente.
3. Verifique se a arquitetura suporta os novos recursos.
4. Apresente decisões técnicas e dependências externas necessárias.
5. Não sobrescreva funcionalidades existentes sem necessidade.

Durante a implementação:
1. Desenvolva por etapas pequenas e verificáveis.
2. Preserve funcionalidades aprovadas anteriormente.
3. Crie migrações de banco de dados versionadas.
4. Proteja operações administrativas e financeiras no servidor.
5. Documente configurações e variáveis de ambiente.
6. Nunca coloque segredos reais no ZIP ou no repositório.
7. Use dados fictícios somente em ambiente de demonstração, identificando-os claramente.

Ao finalizar cada etapa, informe o que foi implementado, o que foi testado, o que depende de credenciais ou serviços externos e o que ainda está pendente. Não declare que um recurso está pronto sem ter executado os testes correspondentes.

**RESULTADO ESPERADO:** o NEWSKMUSIC deverá oferecer uma experiência acolhedora e completa para fãs de K-pop, com contas administrativas protegidas, perfis personalizáveis com GIF, níveis Normal e VIP, assinatura transparente de R$ 19,99 por mês e destaques justos e bem identificados. Todos os recursos deverão ser funcionais, seguros, acessíveis e integrados ao restante da plataforma.

# 36. PWA COMPLETA — INSTALAÇÃO PELO NAVEGADOR

Além dos aplicativos nativos Android e iOS, desenvolva uma PWA (Progressive Web App) completa e instalável. A PWA deverá permitir que o usuário adicione o NEWSKMUSIC à tela inicial e abra a plataforma em uma janela semelhante a aplicativo, nos navegadores e dispositivos compatíveis.

## 36.1. Requisitos técnicos obrigatórios da PWA

Implemente e valide:
* `manifest.webmanifest` válido, com `name`, `short_name`, `description`, `start_url`, `scope`, `display: standalone` (ou `minimal-ui` quando necessário), `theme_color`, `background_color`, orientação apropriada e ícones nos tamanhos exigidos.
* Ícones próprios do NEWSKMUSIC, incluindo pelo menos 192×192 e 512×512, além de variantes maskable quando aplicável. Não use ícones genéricos como entrega final.
* `service worker` registrado em produção por HTTPS, com estratégia de cache adequada para arquivos estáticos e recursos públicos.
* Tela de abertura/cores coerentes com a identidade visual, quando suportadas pelo navegador/sistema.
* Fluxo de instalação: instruções para Android/Chrome e para iPhone/iPad via Safari (Compartilhar > Adicionar à Tela de Início), com detecção de compatibilidade sem prometer que todos os navegadores oferecem o mesmo botão.
* Tratamento do evento de instalação quando disponível, sem exibir botão que não funciona. Se o navegador não oferecer instalação programática, apresentar instruções específicas do dispositivo.
* Página ou estado offline elegante, explicando que a conexão é necessária para mensagens, compras, autenticação e dados atualizados.
* Atualização controlada do service worker, aviso de nova versão e opção de atualizar sem perder dados não enviados.
* Navegação por deep links/rotas, abertura de links compartilhados e fallback correto para rotas internas no servidor de hospedagem.
* HTTPS obrigatório em produção.
* Metadados, ícones, cores e nome da aplicação consistentes com a marca.

## 36.2. Estratégia de cache e funcionamento offline

Não armazene indiscriminadamente informações privadas. Defina explicitamente o que pode ser armazenado em cache:
* Cache-first para arquivos estáticos versionados (CSS, JavaScript, fontes e ícones).
* Network-first ou stale-while-revalidate para conteúdos públicos que possam ficar temporariamente desatualizados.
* Não colocar tokens de autenticação, dados pessoais, mensagens privadas, dados de pagamento, respostas administrativas ou conteúdo sensível em cache público.
* Limpar caches antigos durante atualizações e no logout, conforme a arquitetura.
* Mostrar claramente quando um conteúdo está desatualizado ou indisponível offline.
* Não simular envio de mensagem, publicação, compra ou pagamento offline. Se houver fila local para rascunhos, sincronizar somente após reconexão e pedir confirmação quando necessário.
* Proteger contra cache poisoning, exposição entre usuários no mesmo dispositivo e persistência indevida após logout.

## 36.3. Notificações na PWA

Implementar Web Push apenas onde houver suporte e após consentimento explícito do usuário. Explicar como ativar e desativar notificações. Proteger chaves VAPID no servidor, validar inscrições e permitir revogação. Não prometer notificações em navegadores ou versões de sistema que não suportem o recurso. Evitar enviar conteúdo privado sensível no texto de notificações exibidas na tela bloqueada.

## 36.4. Testes de instalação PWA

Testar pelo menos:
* Manifesto carregado e sem erros.
* Service worker instalado e atualizado corretamente.
* Ícones em tamanhos e formatos adequados.
* Instalação em Android/Chrome compatível.
* Instalação em iOS/iPadOS por Safari, quando suportada.
* Abertura em modo standalone.
* Rotas internas após abrir pelo ícone.
* Atualização de versão sem tela branca.
* Comportamento offline e reconexão.
* Logout e limpeza de dados sensíveis.
* Notificações com consentimento e revogação.
* Acessibilidade, responsividade e desempenho.

# 37. ENTREGA DOS APLICATIVOS INSTALÁVEIS E PUBLICAÇÃO

Entregue os artefatos e instruções necessários para que a proprietária consiga instalar, testar e, quando tiver as contas e certificados necessários, publicar o NEWSKMUSIC.

## 37.1. Android

* Projeto Android configurado e build reproduzível.
* APK assinado para testes e instalação direta em dispositivos compatíveis.
* AAB assinado para envio à Google Play.
* Nome, identificador de pacote, ícone, splash screen, permissões e versão configurados.
* Instruções de assinatura e proteção do keystore. O keystore e suas senhas não devem ser incluídos no ZIP público.
* Documentação de instalação do APK, atualização, backup seguro das chaves e geração de nova versão.
* Testes em dispositivos/emuladores e diferentes versões Android suportadas.

## 37.2. iOS

* Projeto iOS preparado para compilação e distribuição.
* Configuração de Bundle Identifier, ícones, splash screen, permissões e versões.
* Instruções para gerar build assinado e distribuir por TestFlight/App Store.
* Explicar que a distribuição iOS depende de conta Apple Developer, certificados, provisioning profiles e processo de revisão da Apple.
* Não prometer um IPA instalável universalmente nem afirmar que o app foi publicado sem concluir assinatura, envio e aprovação.
* Se a compilação depender de macOS/Xcode ou serviço de build em nuvem, documentar exatamente a dependência e os passos necessários.

## 37.3. PWA e Web

* Código-fonte web pronto para produção.
* Manifesto, service worker, ícones, estratégia de cache e instruções de hospedagem.
* Configuração HTTPS, domínio, redirecionamentos e fallback de rotas.
* Guia para instalar em Android e iOS.
* Guia de atualização e desinstalação.

## 37.4. Regras de entrega e honestidade técnica

Não basta criar pastas ou configurações vazias. Gere os arquivos reais de projeto e, quando o ambiente de desenvolvimento permitir, execute os builds e testes. Se não for possível gerar APK/AAB/IPA neste ambiente, entregue o projeto configurado e documente a razão, as credenciais ou ferramentas externas necessárias e os comandos exatos para gerar cada artefato. Nunca invente links de download, certificados, resultados de build ou publicação concluída.

# 38. ARQUITETURA RECOMENDADA PARA WEB, PWA E APLICATIVOS NATIVOS

Antes de escolher a arquitetura definitiva, inspecione o projeto existente e preserve a tecnologia que já estiver funcional, desde que seja adequada. Se estiver começando do zero, proponha uma arquitetura que permita compartilhar regras de negócio, design tokens, tipos e acesso ao backend entre Web/PWA e aplicativos nativos.

Considere uma das opções e justifique a escolha:
* React Native + Expo com suporte web/PWA, caso as bibliotecas e recursos necessários sejam compatíveis; ou
* Aplicação Web React/Next.js para site/PWA e aplicativo React Native/Expo para Android/iOS, compartilhando backend, API, autenticação, tipos e componentes reutilizáveis quando viável.

Não force uma única base de interface se isso comprometer acessibilidade, desempenho ou compatibilidade. Todas as plataformas deverão compartilhar as mesmas contas e dados através do backend, com autorização no servidor. Documente limitações, dependências e custos de serviços externos.

Inclua scripts documentados para desenvolvimento, lint, typecheck, testes, build web, build Android e build iOS. Inclua `.env.example` apenas com nomes de variáveis e valores fictícios; nunca inclua chaves reais.

# 39. DOCUMENTAÇÃO OBRIGATÓRIA NO PACOTE FINAL

Inclua no projeto:
* `README.md` com visão geral e requisitos.
* Guia de instalação local passo a passo.
* Guia de configuração do banco de dados e migrações.
* Guia de configuração de autenticação, e-mail e armazenamento.
* Guia para criar e verificar as duas contas administrativas.
* Guia de configuração segura de variáveis de ambiente.
* Guia de execução de testes.
* Guia de build e instalação Android (APK/AAB).
* Guia de build e distribuição iOS (TestFlight/App Store).
* Guia de instalação, hospedagem e atualização da PWA.
* Lista de serviços externos necessários, custos conhecidos quando verificáveis e etapas que dependem da proprietária.
* Relatório do que foi implementado, testado, não testado e ainda pendente.

# 40. CRITÉRIOS FINAIS DE ACEITAÇÃO — ADMINISTRAÇÃO E INSTALAÇÃO

O projeto só poderá ser considerado concluído nesta parte quando:
1. Existirem exatamente duas contas administrativas iniciais configuradas com os e-mails especificados na seção 27, após verificação de propriedade dos endereços.
2. A conta `[E-MAIL DA CEO CONFIGURADO PRIVADAMENTE]` possuir papel CEO/administradora principal.
3. A conta `[E-MAIL DA SEGUNDA ADMINISTRADORA CONFIGURADO PRIVADAMENTE]` possuir papel de administradora com permissões controladas.
4. A senha temporária não estiver embutida no código, frontend, ZIP público, logs ou banco em texto puro; a troca/ativação segura estiver implementada.
5. MFA e controles de sessão estiverem configurados quando suportados.
6. O site funcionar em HTTPS e a PWA passar nos testes de manifesto, service worker e instalação nos navegadores compatíveis.
7. O projeto Android estiver configurado para gerar APK e AAB assinados, sem incluir chaves privadas no pacote.
8. O projeto iOS estiver preparado para build e distribuição, com dependências de Apple Developer claramente documentadas.
9. As versões Web/PWA, Android e iOS compartilharem autenticação e dados por meio do backend.
10. A documentação explicar o que foi realmente compilado e testado, o que depende de contas externas e como concluir cada etapa.

**Instrução final à IA desenvolvedora:** leia o documento inteiro, faça uma análise de requisitos e arquitetura antes de alterar o código, identifique conflitos e dependências, proponha um plano por etapas e implemente sem apagar funcionalidades existentes. Priorize segurança, funcionamento real, acessibilidade, testes e documentação. Não afirme que algo está pronto quando for apenas uma tela ou configuração visual.


# 41. BIBLIOTECA DE IMAGENS E CONTEÚDO VISUAL INICIAL DO NEWSKMUSIC

Esta seção é obrigatória. O projeto deverá incluir uma biblioteca organizada de imagens e mídias fornecidas pela proprietária, para que a identidade visual e as primeiras publicações já estejam preparadas desde a primeira versão. Não trate imagens locais como se a IA já tivesse acesso a elas: só utilize arquivos que estejam efetivamente anexados, dentro do ZIP do projeto ou disponíveis na pasta de trabalho autorizada.

## 41.1. Inventário e aproveitamento dos arquivos existentes
* Antes de criar imagens novas, examine recursivamente as pastas do projeto e os arquivos de mídia fornecidos pela proprietária.
* Identifique imagens que possam ser usadas como logotipo, ícone do aplicativo, capa, banners, fotos de perfil, imagens de grupos/artistas e publicações iniciais.
* Gere um inventário com nome do arquivo, formato, dimensões, tamanho, proporção, localização, finalidade sugerida e eventuais problemas de qualidade.
* Não presuma que toda imagem encontrada é apropriada para publicação. Separe arquivos pessoais, duplicados, incompletos, ilegíveis ou sem autorização de uso.
* Não descarte nem sobrescreva os originais. Preserve uma cópia original e trabalhe com versões otimizadas em diretórios separados.
* Se nenhum arquivo visual tiver sido fornecido, crie a estrutura de pastas e um relatório indicando exatamente quais imagens ainda precisam ser enviadas. Não invente que encontrou imagens no computador da proprietária.

## 41.2. Estrutura de pastas obrigatória
Organize os arquivos de mídia, no mínimo, assim:
* `assets/brand/`: logotipo, variações da marca e elementos de identidade visual.
* `assets/app-icon/source/`: arquivo original escolhido para o ícone.
* `assets/app-icon/generated/`: ícones exportados nos tamanhos e formatos exigidos pela Web/PWA, Android e iOS.
* `assets/splash/`: imagens de abertura e telas iniciais.
* `assets/posts/initial/`: imagens aprovadas para as publicações iniciais de demonstração ou lançamento.
* `assets/posts/community/`: imagens fornecidas e aprovadas para conteúdos da comunidade, quando aplicável.
* `assets/profiles/`: imagens de perfil e capas de demonstração autorizadas.
* `assets/banners/`: banners e peças promocionais.
* `assets/gallery/originals/`: cópias originais preservadas.
* `assets/gallery/optimized/`: cópias comprimidas e redimensionadas para uso no aplicativo.
* `assets/docs/`: inventário, créditos, licenças e instruções de uso das mídias.

Inclua arquivos `.gitkeep` nas pastas vazias e um `ASSET_INVENTORY.csv` ou equivalente para registrar os arquivos recebidos e sua utilização.

## 41.3. Ícone oficial do aplicativo
* Primeiro procure um logotipo ou símbolo oficial do NEWSKMUSIC entre os arquivos fornecidos.
* Se existir, utilize-o como referência principal e preserve a identidade da marca. Se não existir, proponha uma direção visual coerente e solicite aprovação antes de substituir a marca por uma criação definitiva.
* O ícone deve ser legível em tamanhos pequenos, reconhecível, centralizado e sem texto minúsculo.
* Prepare exportações nos tamanhos, formatos e zonas seguras exigidos pelas plataformas atuais: favicon e ícones PWA, ícones adaptativos Android e conjunto de ícones iOS.
* Gere também a configuração de ícones no manifesto PWA e nos arquivos de build nativos.
* Não use imagens de artistas, grupos, personagens, marcas ou fotografias de terceiros como ícone oficial sem autorização/licença adequada.
* Documente qual arquivo é a fonte oficial e quais arquivos são derivados.

## 41.4. Publicações iniciais já preparadas
* Crie uma área de feed inicial com algumas publicações de exemplo usando exclusivamente imagens fornecidas e aprovadas pela proprietária, quando disponíveis.
* As publicações devem ser cadastradas por seed/migração de demonstração claramente identificada, ou por fluxo administrativo de publicação, e não inseridas de modo improvisado diretamente no código da interface.
* Cada publicação deverá possuir imagem, texto/legenda, autor ou fonte, data, categoria, texto alternativo, status de publicação e indicação de conteúdo demonstrativo quando aplicável.
* Não invente notícias, datas, declarações, créditos, autoria ou informações sobre artistas. Conteúdos editoriais reais precisam de fonte verificável e créditos.
* Se as imagens disponíveis não tiverem legendas ou contexto, use rascunhos neutros identificados como “rascunho aguardando revisão”, sem publicar automaticamente.
* Disponibilize no painel administrativo uma ferramenta para revisar, editar, aprovar, agendar, publicar e remover essas publicações.
* Permita substituir ou remover imagens sem quebrar o feed e sem deixar links de mídia quebrados.

## 41.5. Tratamento, formatos e desempenho
* Verifique formato, dimensões, proporção, orientação, transparência e integridade de cada arquivo.
* Gere versões responsivas e miniaturas; prefira formatos modernos como WebP/AVIF quando houver suporte e mantenha fallback compatível.
* Preserve transparência quando necessária para logotipos e ícones.
* Defina limites de tamanho e dimensões para uploads, valide MIME type e conteúdo real do arquivo no servidor e remova metadados desnecessários, inclusive geolocalização, quando apropriado.
* Use nomes de arquivo seguros, evite caminhos fornecidos pelo usuário, proteja contra arquivos maliciosos e armazene mídias em storage com permissões adequadas.
* Implemente lazy loading, srcset/tamanhos responsivos, compressão e cache com invalidação correta.
* GIFs animados de perfil devem ter limite de tamanho/duração e alternativa estática; respeite acessibilidade e redução de movimento.
* Não converta GIF animado em imagem estática sem informar a limitação.

## 41.6. Direitos autorais, privacidade e aprovação
* Utilize somente imagens próprias, licenciadas ou fornecidas com autorização de uso compatível com a finalidade.
* Não presuma que uma imagem salva no computador pode ser publicada ou redistribuída.
* Registre autor/crédito, origem, licença ou autorização e restrições de uso quando conhecidos.
* Não exponha fotos pessoais, capturas privadas, documentos ou imagens sensíveis encontradas nas pastas.
* Exija aprovação administrativa antes de publicar qualquer mídia cuja finalidade, autoria ou permissão não esteja clara.

## 41.7. Entrega e validação visual
* Inclua no ZIP final a estrutura de pastas, os arquivos realmente recebidos e aprovados, os derivados necessários e o inventário.
* Não inclua imagens fictícias no lugar de arquivos ausentes; use placeholders claramente identificados apenas na interface de desenvolvimento.
* Teste ícones e imagens em PWA, Android, iOS e Web, em telas pequenas e grandes, modo claro/escuro quando aplicável e diferentes densidades de pixels.
* Verifique se nenhuma imagem está quebrada, esticada, cortada de forma inadequada ou com baixa resolução.
* Ao final, entregue uma lista de imagens utilizadas, imagens pendentes, arquivos gerados e eventuais permissões que ainda precisam ser confirmadas.

**Regra essencial:** se os arquivos visuais estiverem apenas no computador da proprietária e não tiverem sido enviados no projeto, pare e solicite que ela anexe as imagens ou um ZIP com elas. Não alegue acesso ao disco local do computador.


# 42. ARQUIVOS OFICIAIS DE IDENTIDADE VISUAL FORNECIDOS — LOGO.PNG E WALLPAPER.PNG

A proprietária forneceu uma única imagem composta com dois painéis visuais. Essa composição já foi separada em dois arquivos PNG independentes e incluída neste pacote. Utilize os arquivos reais abaixo; não crie substitutos nem trate a imagem composta como se fosse um único recurso.

**Arquivos oficiais incluídos:**
* `assets/brand/logo.png` — painel quadrado com o logotipo NEWSKMUSIC. Dimensões do arquivo entregue: 820 × 803 pixels.
* `assets/brand/wallpaper.png` — painel vertical de fundo/papel de parede. Dimensões do arquivo entregue: 576 × 1024 pixels.
* `assets/app-icon/source/logo-source.png` — cópia de referência do logotipo para o processo de preparação de ícones.
* `assets/gallery/originals/` — preservar a imagem composta original recebida, quando ela estiver incluída no pacote de trabalho.

## 42.1. Uso correto do logotipo
* Trate `assets/brand/logo.png` como a arte oficial da marca NEWSKMUSIC.
* Preserve cores, proporções, desenho, tipografia e composição. Não redesenhe nem aplique filtros que alterem a identidade.
* Não estique a imagem para preencher formatos diferentes. Utilize `contain`, margens de segurança e fundos coerentes quando necessário.
* Para ícones pequenos, avalie a legibilidade do monograma. Se for preciso gerar uma versão simplificada, crie um derivado separado, mantenha o original intacto e documente a alteração. Não use texto minúsculo ilegível no ícone.
* Exporte os tamanhos e variantes exigidos para favicon, manifest PWA, ícones adaptativos Android e ícones iOS, usando as ferramentas de build da plataforma.

## 42.2. Uso correto do wallpaper
* Trate `assets/brand/wallpaper.png` como arte vertical oficial para fundos, telas de abertura ou áreas visuais selecionadas.
* Preserve a arte original e produza recortes derivados em arquivos separados quando diferentes proporções forem necessárias.
* Garanta contraste suficiente para textos, botões e campos; use overlays discretos ou superfícies sólidas quando necessário.
* Não aplique o wallpaper em todas as páginas por padrão. Evite repetição visual, excesso de textura e impacto negativo na leitura ou no desempenho.
* Use carregamento otimizado, versões responsivas e fallback apropriado.

## 42.3. Organização e validação
* Mantenha os caminhos `assets/brand/logo.png` e `assets/brand/wallpaper.png` exatamente como definidos, salvo se a arquitetura existente exigir uma mudança documentada.
* Atualize `assets/ASSET_INVENTORY.csv` com nome, formato, dimensões, finalidade, origem, licença/autorização informada e status de aprovação.
* Preserve os arquivos fornecidos e gere derivados em pastas próprias; nunca sobrescreva os originais.
* Teste a marca e o wallpaper em desktop, celular, PWA, Android e iOS, verificando recorte, nitidez, contraste e carregamento.
* Não declare ícones nativos finais, APK, AAB ou aplicativo iOS como concluídos sem gerar e testar os artefatos correspondentes.

**Regra obrigatória:** os dois PNGs entregues neste pacote são arquivos distintos e devem permanecer separados. `logo.png` é a marca; `wallpaper.png` é o fundo vertical. Não inverter suas finalidades.
