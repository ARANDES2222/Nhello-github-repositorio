# Segurança — regras obrigatórias

- Nunca versionar `.env`, chaves privadas, service role, tokens, senhas, keystores ou certificados.
- Não confiar em validações apenas no frontend.
- Ativar RLS em todas as tabelas expostas e escrever políticas mínimas por operação.
- Papéis administrativos são atribuídos somente no backend; usuários não podem editar `role`.
- MFA obrigatório para administradores.
- Rate limiting e proteção contra spam, abuso de denúncias e brute force.
- Validar MIME real, tamanho e conteúdo dos uploads; limitar GIF, imagem, vídeo e anexos.
- Sanitizar conteúdo de usuário e prevenir XSS, CSRF quando aplicável, SQL injection e IDOR.
- Não armazenar dados de cartão. Usar checkout hospedado/tokenização do provedor.
- Validar assinatura dos webhooks e implementar idempotência.
- Registrar ações administrativas sem armazenar conteúdo privado desnecessário.
- Implementar exportação e exclusão de dados conforme LGPD.
- Definir retenção, backups criptografados e teste periódico de restauração.
- Ter canal privado de reporte de vulnerabilidade antes de abrir contribuições públicas.
