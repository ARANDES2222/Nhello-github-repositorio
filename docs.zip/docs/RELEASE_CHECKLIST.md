# Checklist de release

## Código
- [ ] `npm ci` ou instalação limpa funciona
- [ ] `npm run typecheck` passa
- [ ] `npm run build` passa
- [ ] Testes unitários, integração e E2E passam
- [ ] Sem segredos no código nem no histórico Git

## PWA
- [ ] HTTPS ativo
- [ ] Manifest válido e ícones em tamanhos adequados
- [ ] Service worker testado; estratégia de cache não guarda dados privados indevidamente
- [ ] Instalação, atualização e modo offline testados
- [ ] Lighthouse/auditoria de acessibilidade revisada

## Android
- [ ] Identificador e versão definidos
- [ ] Ícones e splash em resoluções exigidas
- [ ] Testado em dispositivos reais
- [ ] APK assinado para distribuição de teste
- [ ] AAB assinado para Google Play
- [ ] Política de privacidade e declarações da loja concluídas

## iOS
- [ ] Build em macOS/Xcode
- [ ] Bundle ID, certificados e provisioning configurados
- [ ] TestFlight validado
- [ ] Permissões e privacidade declaradas
- [ ] Revisão e publicação na App Store concluídas

## Operação
- [ ] Supabase RLS revisado
- [ ] SMTP e recuperação de conta testados
- [ ] Backups e restauração testados
- [ ] Monitoramento e alertas configurados
- [ ] Termos, política de privacidade e suporte publicados
- [ ] Testes de pagamento e webhooks em sandbox e produção
