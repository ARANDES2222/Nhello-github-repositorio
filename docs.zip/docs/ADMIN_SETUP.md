# Configuração das duas administradoras

O produto deverá iniciar com duas contas administrativas designadas pela proprietária. Os e-mails reais devem ser inseridos somente no painel privado do provedor de autenticação durante a implantação; não devem aparecer no código, nas migrations, no ZIP público ou no GitHub.

1. Configure o provedor de autenticação.
2. Convide as duas administradoras individualmente.
3. Cada pessoa define sua própria senha por convite seguro.
4. Exija confirmação de e-mail e MFA.
5. Após confirmar os UUIDs, atribua papéis no backend por função privilegiada protegida.
6. Aplique RLS e testes de autorização.
7. Registre alterações e ações administrativas em audit log.
8. Garanta que nenhum usuário consiga alterar sua própria role.

Não utilize senha compartilhada, senha padrão, credenciais hardcoded ou acesso administrativo baseado apenas em URL.
