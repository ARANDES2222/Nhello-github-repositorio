# Roadmap de implementação

## Fase 0 — Fundação (este pacote)
- [x] Estrutura React + TypeScript + Vite
- [x] Configuração PWA inicial
- [x] Configuração Capacitor
- [x] Identidade visual adicionada quando os assets de origem estão disponíveis
- [ ] Instalar dependências e validar build em ambiente do desenvolvedor

## Fase 1 — Backend e identidade
- Supabase Auth, confirmação de e-mail e recuperação de senha
- Perfil, papéis e políticas RLS
- Fluxo seguro de convite dos dois administradores
- Logs de auditoria

## Fase 2 — Comunidade
- Feed persistente, posts, mídia, comentários, curtidas, salvos e republicações
- Busca e descoberta
- Seguir/deixar de seguir e notificações

## Fase 3 — Comunicação e moderação
- Chat realtime e bloqueios
- Denúncias, revisão, recursos e sanções proporcionais
- Ferramentas de suporte

## Fase 4 — Marketplace e VIP
- Anúncios, vendedores, avaliações e denúncias
- Assinatura VIP R$ 19,99/mês com provedor de pagamento
- Webhooks idempotentes, cancelamento, reembolso e histórico
- Benefícios VIP e regras contra abuso

## Fase 5 — Aplicativos e lançamento
- Testes PWA em navegadores/dispositivos
- Android: APK de teste e AAB assinado
- iOS: build em macOS/Xcode, TestFlight e App Store
- Acessibilidade, performance, segurança e LGPD
- Monitoramento, backups e plano de resposta a incidentes
