# Solicitação revisada para desenvolvimento

Utilize todos os materiais, arquivos, imagens, especificações e decisões já desenvolvidos para o NEWSKMUSIC. Dê continuidade ao projeto, preservando a identidade visual e os requisitos aprovados. Desenvolva uma plataforma web responsiva, PWA instalável e aplicativos Android/iOS com base de código compartilhada sempre que adequado.

O projeto deverá incluir código-fonte, banco de dados, autenticação, feed, perfis, publicações, pesquisa, mensagens, marketplace, assinatura VIP, moderação, painel administrativo, documentação, testes e instruções de implantação. Implemente em etapas, valide cada entrega e informe claramente o que está funcional, demonstrativo ou depende de serviços externos.

O repositório será público no GitHub. Portanto, não inclua senhas, tokens, chaves privadas, dados pessoais desnecessários, arquivos `.env`, certificados ou credenciais administrativas. As duas contas administrativas iniciais devem ser convidadas e verificadas diretamente no serviço de autenticação, com MFA e permissões concedidas no servidor.

A versão atual do projeto é uma fundação frontend interativa de demonstração. Não declare autenticação, pagamentos, chat, marketplace, painel administrativo ou sincronização multiusuário como concluídos até que sejam conectados ao backend e testados.
